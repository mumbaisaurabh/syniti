package com.saurabh.syniti;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * program to find all invalid ids and print them in the console.
 * Saurabh Tiwari
 * 19-05-2021
 */
public class JsonReader {
    static Map<String, String> validDataMap = new HashMap<>();
    static List<String> invalidIds = new ArrayList<>();
    static String inputFile = "C:/Users/sati01/Downloads/software-engineer-questions-master/data.json";

    public static void main(String[] args) {
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader(inputFile)) {
            Object obj = jsonParser.parse(reader);
            JSONArray dataList = (JSONArray) obj;
            dataList.forEach(d -> parseDataObject((JSONObject) d));

            invalidIds.forEach(id -> System.out.println(id));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static void parseDataObject(JSONObject data) {
        boolean isValid = false;
        String id = (String) data.get("id");
        String name = (String) data.get("name");
        isValid = validateNullMIssingBlank(id, name);

        if (isValid) {
            String address = (String) data.get("address");
            isValid = validateNullMIssingBlank(id, address);

            if (isValid) {
                String zip = (String) data.get("zip");
                isValid = validateNullMIssingBlank(id, zip);
                if (isValid) {
                    isValid = validateUSZipCode(id, zip);
                    if (isValid) {
                        String oldId = validDataMap.put(name + "_" + address + "_" + zip, id);
                        if (oldId != null) {
                            invalidIds.add(id);
                            invalidIds.add(oldId);
                        }
                    }
                }
            }
        }
    }

    private static boolean validateUSZipCode(String id, String zip) {
        String regex = "^[0-9]{5}(?:-[0-9]{4})?$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(zip);
        if (matcher.matches()) {
            return true;
        }
        invalidIds.add(id);
        return false;
    }

    private static boolean validateNullMIssingBlank(String id, String input) {
        if (input == null || input.equals("")) {
            invalidIds.add(id);
            return false;
        }
        return true;
    }
}
